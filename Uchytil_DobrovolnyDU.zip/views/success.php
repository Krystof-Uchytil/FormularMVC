<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title>Úspěšně odesláno</title>
</head>
<body>
    <h1>Formulář byl úspěšně odeslán!</h1>
    <a href="?controller=form&action=index">Zpět na formulář</a>
</body>
</html>